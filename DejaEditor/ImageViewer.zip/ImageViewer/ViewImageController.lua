require "UIKit"

ViewImageController = {};
ViewImageController.__index = ViewImageController;
setmetatable(ViewImageController, UIViewController);

function ViewImageController:viewDidLoad()
	super:viewDidLoad();
	if not self.image then
		return;
	end
	self.scrollView = UIScrollView:create();
	self.scrollView:setFrame(self:view():bounds());
	self.scrollView:setAutoresizingMask(math::bor(2,16));
	self.scrollView:setBackgroundColor(UIColor:create(255,0,0));
	--self:view():addSubview(self.scrollView);
	
	self.imgView = UIImageView:create(self.image);
	self.imgView:setFrame(self:view():bounds());
	self.imgView:setAutoresizingMask(math::bor(2,16));
	local _,_,viewwid,viewhei = self:view():bounds();
	local imgwid,imghei = self.image:size();
	
	if imgwid > viewwid or imghei > viewhei then
		self.imgView:setContentMode(1);
	else
		self.imgView:setContentMode(4);
	end
	
	self:view():addSubview(self.imgView);
end

function ViewImageController:shouldAutorotate()
	return true;
end