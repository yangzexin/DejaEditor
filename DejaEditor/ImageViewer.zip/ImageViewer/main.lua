require "ViewImageController"
require "AppContext"

function main(args)
	--utils::log(args);
	
	--local img = UIImage:imageWithResName("IMG_0027.JPG");
	local img = UIImage:imageWithData(NSData:get(args), 1);
	local vic = ViewImageController:create("ImageViewer"):retain();
	vic.image = img:retain();
	function vic:viewDidPop()
		--vic:release();
		AppContext.destory();
	end
	vic:pushToRelatedViewController();
	return nil;
end
