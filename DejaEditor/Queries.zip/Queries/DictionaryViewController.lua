require "UIKit"
require "DictDotCNDictionary"
require "CommonUtils"

DictionaryViewController = {};
DictionaryViewController.__index = DictionaryViewController;
setmetatable(DictionaryViewController, UIViewController);

function DictionaryViewController:dealloc()
    getmetatable(getmetatable(self)).dealloc(self);
end

function DictionaryViewController:viewWillAppear()
	super:viewWillAppear();
end

function DictionaryViewController:searchWord(word)
	local bself = self;
	local URLString = dictionaryURLForWord(word); 
	 local req = HTTPRequest:get(URLString):retain(); 
	 bself:setWaiting(true); 
	 function req:response(res, errorString) 
		 bself:setWaiting(false); 
		local html = ""; 
		 if StringUtils.length(errorString) ~= 0 then 
			 html = "网络连接错误"; 
		 end 
		 local html = DictDotCNDictionary.analyseHTML(res); 
		 bself.webView:loadHTMLString(bself.html..html); 
		safety_release(req);
	 end
end

function DictionaryViewController:viewDidLoad()
	super:viewDidLoad();
    local bself = self;

    self.webView = UIWebView:create():retain();
    self.webView:setFrame(self:view():bounds());
    self.webView:setAutoresizingMask(math::bor(UIViewAutoresizingFlexibleWidth, UIViewAutoresizingFlexibleHeight));
	self:view():addSubview(self.webView);
	
    local webViewDelegate = {};
    function webViewDelegate:didStartLoad()
        bself:setWaiting(true);
    end
    function webViewDelegate:didFinishLoad()
        bself:setWaiting(false);
        --bself.webView:setScalesPageToFit(true);
    end
    function webViewDelegate:shouldStartLoadWithRequest(webView, URLString, navigationType)
	if toLuaBool(string::invokeMethod(URLString, "hasPrefix:", "command://")) then
		local command = StringUtils.substring(URLString, 10, StringUtils.length(URLString));
		if toLuaBool(string::invokeMethod(command, "hasPrefix:", "search:")) then
			local word = StringUtils.substring(command, 7, StringUtils.length(command));
			utils::log(word);
			--word  =string::invokeMethod(word, "stringByReplacingPercentEscapesUsingEncoding:", 4);
			bself:searchWord(word);
		end
		return false;
	end
        return true;
    end
    function webViewDelegate:didFailLoadWithError(webView, errorString)
	bself:setWaiting(false);
        print(errorString);
    end
    self.webView:setDelegate(webViewDelegate);
	self.html = [===[
		<script>
			function searchButtonTapped(){
				var field = document.getElementById("wordTextField");
				var url ="command://search:" + field.value;
				window.location.href = url;
			}
		</script>
		<div>
			<input type="text" id="wordTextField"  style="width:88%;height:35px;font-size:16px;"/>
			<button style="width:80px;height:32px;" onclick="searchButtonTapped()">查询</button>
		</div>
	]===];
	self.webView:loadHTMLString(self.html);
    --self.webView:loadURLString("http://3g.dict.cn");
end

function DictionaryViewController:shouldAutorotate()
    return true;
end

function dictionaryURLForWord(word)
	local haiciURL = "http://3g.dict.cn/s.php?q=";
	word = string.gsub(word, " ", "+");
	return haiciURL..word;
end

--[[
function main(args)
    if args then
        po(args);
    end
end]]