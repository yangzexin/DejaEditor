require "UIViewController"
require "FileUtils"
require "UITableView"
require "StringUtils"
require "UIBarButtonItem"

class(FileListViewController, UIViewController);

function FileListViewController:viewDidLoad()
	super:viewDidLoad();
	local bself = self;
	if self.path  == nil then
		self.path = FileUtils.documentPath();
	end
	
	self.fileList = FileUtils.contentsOfDirectoryAtPath(self.path):retain();
	
	self.selectButton = UIBarButtonItem:create("选择"):retain();
	self.selectButton:setStyle(2);
	function self.selectButton:tapped() 
		if bself.fileDidSelected then
			bself:fileDidSelected(bself.selectedPath);
		end
	end
	--self:navigationItem():setRightBarButtonItem(self.selectButton);
	
	self.tableView = UITableView:create():retain();
	self.tableView:setAutoresizingMask(math::bor(2, 16));
	self.tableView:setFrame(self:view():bounds());
	self:view():addSubview(self.tableView);
	
	local tableViewDataSource = {};
	function tableViewDataSource:numberOfRowsInSection(tableView, section)
		return bself.fileList:count();
	end
	local cellIdentifier = "cellid";
	function tableViewDataSource:cellForRowAtIndexPath(tableView, indexPath)
		local cell = bself.tableView:dequeueReusableCellWithIdentifier(cellIdentifier);
		if not cell then
			cell = UITableViewCell:create(cellIdentifier);
		end
		local fileName = bself.fileList:objectAtIndex(indexPath:row());
		local filePath = StringUtils.appendingPathComponent(bself.path, fileName);
		if FileUtils.isDirectory(filePath) then
			cell:textLabel():setText("📁"..fileName);
		else
			cell:textLabel():setText("📄"..fileName);
		end
		return cell;
	end
	self.tableView:setDataSource(tableViewDataSource);
	
	local tableViewDelegate={};
	function tableViewDelegate:didSelectRowAtIndexPath(tableView, indexPath)
		local fileName = bself.fileList:objectAtIndex(indexPath:row()); 
		local filePath = StringUtils.appendingPathComponent(bself.path, fileName);
		if FileUtils.isDirectory(filePath) then
			bself.tableView:deselectRowAtIndexPath(indexPath);
			bself:navigationItem():setRightBarButtonItem(nil);
			local tmpFileVC = FileListViewController:create(bself:title()):retain();
			tmpFileVC.fileDidSelected = bself.fileDidSelected;
			function tmpFileVC:viewDidPop()
				tmpFileVC:release();
			end
			tmpFileVC.path = filePath;
			bself:navigationController():pushViewController(tmpFileVC, true);
		else
			bself.selectedPath = filePath;
			bself:navigationItem():setRightBarButtonItem(bself.selectButton);
		end
		
	end
	self.tableView:setDelegate(tableViewDelegate);
	
	local _,_,vw,vh = self:view():bounds();
	local headerView = UIView:create();
	headerView:setFrame(0, 0, vw, 60);
	self.tableView:setTableHeaderView(headerView);
	local titleLabel = UILabel:create(self.path);
	titleLabel:setFrame(15, 0, vw - 30, 60);
	titleLabel:setNumberOfLines(0);
	headerView:addSubview(titleLabel);
end

--[[function main()
	local vc = FileListViewController:create("Files"):retain();
	vc:pushToRelatedViewController();
	function vc:fileDidSelected(path)
		utils::log(path);
	end
end]]