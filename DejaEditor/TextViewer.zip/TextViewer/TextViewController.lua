require "UIViewController"
require "NotificationObserver"
require "Utils"
require "FileListViewController"
require "UITextView"
require "UIAnimation"

class(TextViewController, UIViewController);

function TextViewController:viewWillAppear()
	super:viewWillAppear();
	self:navigationController():setToolbarHidden(false);
end

function TextViewController:viewWillDisappear()
	super:viewWillDisappear();
	self:navigationController():setToolbarHidden(true, true);
end

function TextViewController:viewDidLoad()
	super:viewDidLoad();
	local bself = self;
	self:setTitle("文本查看")
	self.textView = UITextView:create():retain();
	self.textView:setFrame(self:view():bounds());
	self.textView:setAutoresizingMask(math::bor(2,16));
	if SystemUtils.isPad() then
		self.textView:setFont(UIFont:create(16));
	else
		self.textView:setFont(UIFont:create(12));
	end
	self:view():addSubview(self.textView);
	self.textView:setEditable(false);
	
	if ustring::length(self.text) ~=0 then
		self.textView:setText(self.text);
	end
	local textViewDelegate = {};
	function textViewDelegate:didBeginEditing(textView)
		
	end
	function textViewDelegate:didEndEditing(textView)
		
	end
	self.textView:setDelegate(textViewDelegate);
	
	self.observer = NotificationObserver:create():retain();
	function self.observer:receive(object, userInfo)
		local nsvalue = userInfo:objectForKey("UIKeyboardFrameEndUserInfoKey");
		
		local frame = runtime::invokeMethod(nsvalue:id(), "CGRectValue");
		local x,y,wid,hei = unpack(stringTableToNumberTable(stringSplit(frame, ",")));
		local tx,ty,tw,th = bself.textView:bounds();
		local _,_,_,vh = bself:view():bounds();
		local _,_,_,toolbarhei = bself:navigationController():toolbar():frame();
		vh =vh +  toolbarhei;
		local anim = UIAnimation:create();
		function anim:animation()
			bself.textView:setFrame(0, 0, tw, vh - hei);
		end
		anim:start();
	end
	self.observer:observe("UIKeyboardWillShowNotification");
	
	self.hideObserver = NotificationObserver:create():retain();
	function self.hideObserver:receive(object, userInfo)
		local anim = UIAnimation:create();
		function anim:animation()
			bself.textView:setFrame(bself:view():bounds());
		end
		anim:start();
	end
	self.hideObserver:observe("UIKeyboardWillHideNotification");
	
	self.saveBtn = UIBarButtonItem:create("保存"):retain();
	self.saveBtn:setStyle(2);
	--self:navigationItem():setRightBarButtonItem(self.saveBtn);
	
	self.selectFileButton = UIBarButtonItem:create("选择文件.."):retain();
	function self.selectFileButton:tapped()
		local fileListVC = FileListViewController:create("选择文件"):retain();
		if bself.lastOpenFilePath then
			local dir = string::invokeMethod(bself.lastOpenFilePath, "stringByDeletingLastPathComponent");
			--fileListVC.path = dir;
		end
		local cancelBtn = UIBarButtonItem:create("取消"):retain();
		function cancelBtn:tapped()
			bself:dismissViewController(true);
			fileListVC:release();
			cancelBtn:release();
		end
		function fileListVC:fileDidSelected(path)
			bself.lastOpenFilePath = path;
			bself.textView:setText(FileUtils.readStringFromFile(path)); 
			cancelBtn:tapped();
		end
		fileListVC:navigationItem():setLeftBarButtonItem(cancelBtn);
		bself:presentViewController(UINavigationController:create(fileListVC), true);
	end
	local toolbarItems = NSMutableArray:create();
	toolbarItems:addObject(UIBarButtonItem:createWithSystemItem(5));
	toolbarItems:addObject(self.selectFileButton);
	self:setToolbarItems(toolbarItems);
end

function TextViewController:shouldAutorotate()
	return true;
end

--[[function main()
	local vc = TextViewController:create():retain();
	vc:pushToRelatedViewController();
end]]