require "UIKit"
require "TextViewController"
require "AppContext"
require "StringUtils"

function main(args)
	local data = nil;
	if args then
		data = NSData:get(args);
	end
	local textvc = TextViewController:create("文本编辑器"):retain();
	if data then
		textvc.text = StringUtils.UTF8StringFromData(data);
	end
	function textvc:viewDidPop()
		self:navigationController():setToolbarHidden(true, false);
		self:release();
	end
	textvc:pushToRelatedViewController();
	return nil;
end
