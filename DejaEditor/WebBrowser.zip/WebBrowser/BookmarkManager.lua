require "FMDatabase"
require "FileUtils"
require "DiarySentenceController"

class(BookmarkManager);
class(BookmarkItem);

function BookmarkManager:init()
	super:init();
	local path = string::invokeMethod(cachePath(), 
		"stringByAppendingPathComponent:", "bookmark_manager.db");
	local dbExists = FileUtils.exists(path);
	self.db = FMDatabase:databaseWithPath(path):retain();
	self.db:open();
	if not dbExists then
		local sql = [===[
			create table bookmark_list(
				uid Integer primary key autoincrement,
				title text,
				url text
			);
		]===];
		local success = self.db:executeUpdate(sql);
		if success then
			utils::log("create table success");
		else
			utils::log("create table failed");
		end
	end
end

function BookmarkManager:bookmarkList()
	local sql = "select * from bookmark_list  order by uid desc"
	--utils::log(sql);
	local rs = self.db:executeQuery(sql);
	local list = {};
	while rs:next() do
		local hi = BookmarkItem:new();
		hi:setTitle(rs:stringForColumn("title"));
		hi:setUrl(rs:stringForColumn("url"));
		hi:setUid(rs:intForColumn("uid"));
		if StringUtils.length(StringUtils.trim(hi:title()))  ~= 0 
			and StringUtils.length(StringUtils.trim(hi:url()))  ~= 0 then
			list[#list + 1] = hi;
		end
	end
	return list;
end

function BookmarkManager:addBookmark(title, url)
	local hid = self:firstBookmarkId(title, url);
	if hid then
		local sql = "delete from bookmark_list where uid="..hid;
		self.db:executeUpdate(sql);
	end
	local sql = "insert into bookmark_list(title, url) values('"..title.."', '"..url.."')";
	--utils::log(sql);
	self.db:executeUpdate(sql);
end

function BookmarkManager:bookmarkExists(title, url)
	local sql = "select title from bookmark_list where title='"..title.."' and url='"..url.."'";
	--utils::log(sql);
	local rs = self.db:executeQuery(sql);
	if rs:next() then
		return true;
	end
	return false;
end

function BookmarkManager:firstBookmarkId(title, url)
	local sql = "select uid from bookmark_list where title='"..title.."' and url='"..url.."'";
	--utils::log(sql);
	local rs = self.db:executeQuery(sql);
	if rs:next() then
		return rs:stringForColumn("uid");
	end
	return nil;
end

function BookmarkManager:deleteBookmarkWithUid(uid)
	local sql = "delete from bookmark_list where uid="..uid;
	--utils::log(sql);
	self.db:executeUpdate(sql);
end

function BookmarkManager:clear()
	
end

function BookmarkManager:dealloc()
	super:dealloc();
	self.db:close();
end

function BookmarkItem:init()
	super:init();
	self._title = "";
	self._url = "";
	self._uid = "";
end

function BookmarkItem:title()
	return self._title;
end

function BookmarkItem:setTitle(title)
	self._title = title;
end

function BookmarkItem:url()
	return self._url;
end

function BookmarkItem:setUrl(url)
	self._url = url;
end

function BookmarkItem:setUid(uid)
	self._uid = uid;
end

function BookmarkItem:uid()
	return self._uid;
end

function BookmarkItem:dealloc()
	super:dealloc();
end