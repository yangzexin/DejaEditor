require "UIViewController"
require "BookmarkManager"

class(BookmarkManagerController, UIViewController);

function BookmarkManagerController:init()
	super:init();
	self.bookmarkList = {};
	self.bookmarkMgr = BookmarkManager:new():retain();
end

function BookmarkManagerController:loadView()
	super:loadView();
	local bself = self;
	self.tableView = UITableView:create():retain();
	self.tableView:setFrame(self:view():bounds());
	self.tableView:setAutoresizingMask(math::bitOr(2,16));
	runtime::invokeMethod(self.tableView:id(), "setRowHeight:", 60);
	self:view():addSubview(self.tableView);
	local tableViewDelegate = {};
	function tableViewDelegate:didSelectRowAtIndexPath(tableView, indexPath)
		tableView:deselectRowAtIndexPath(indexPath);
		local bookmark = bself.bookmarkList[indexPath:row() + 1];
		bself:didSelectBookmark(bookmark:title(), bookmark:url());
	end
	self.tableView:setDelegate(tableViewDelegate);
	local tableViewDataSource = {};
	function tableViewDataSource:numberOfRowsInSection(tableView, section)
		return #bself.bookmarkList;
	end
	function tableViewDataSource:cellForRowAtIndexPath(tableView, indexPath)
		local cell = tableView:dequeueReusableCellWithIdentifier("bm");
		if not cell then
			cell = UITableViewCell:create("bm", "0");
		end
		local bookmark = bself.bookmarkList[indexPath:row() + 1];
		cell:textLabel():setText("🍋 "..bookmark:title());
		return cell;
	end
	function tableViewDataSource:commitEditingStyle(tableView, editingStyle, indexPath)
		if editingStyle == 1 then
			local bm = bself.bookmarkList[indexPath:row() + 1];
			bself.bookmarkMgr:deleteBookmarkWithUid(bm:uid());
			bself:reloadData();
		end
	end
	self.tableView:setDataSource(tableViewDataSource);
	
	self.doneBtn=UIBarButtonItem:create("完成"):retain();
	function self.doneBtn:didTap()
		bself:doneButtonTapped();
	end
	self:navigationItem():setRightBarButtonItem(self.doneBtn);
end

function BookmarkManagerController:viewDidLoad()
	local bself = self;
	self:reloadData();
end

function BookmarkManagerController:reloadData()
	self.bookmarkList = self.bookmarkMgr:bookmarkList(); 
	if self.tableView then
		self.tableView:reloadData();
	end
end

function BookmarkManagerController:didSelectBookmark(title, url)
	
end

function BookmarkManagerController:addBookmark(title, url)
	self.bookmarkMgr:addBookmark(title, url);
	self:reloadData();
end

function BookmarkManagerController:doneButtonTapped()
	
end
