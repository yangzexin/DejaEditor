require "UIKit"
require "Utils"

BrowserTabListController = {};
BrowserTabListController.__index = BrowserTabListController;
setmetatable(BrowserTabListController, UIViewController);

globalSelf = nil;

function BrowserTabListController:dealloc()
    self:releaseFields();
    UIViewController.dealloc(self);
end

function BrowserTabListController:viewWillAppear()
    
end

function BrowserTabListController:viewDidLoad()
    globalSelf = self;
    local bself = self;
    
    self.doneBtn = UIBarButtonItem:create("完成"):retain();
    self.doneBtn:setStyle(2);
    function self.doneBtn:didTap()
        if bself.didDone then
            bself:didDone();
        end
    end
    bself:navigationItem():setRightBarButtonItem(self.doneBtn);
    
    self.addNewTabBtn = UIBarButtonItem:createWithSystemItem(4):retain();
    function self.addNewTabBtn:didTap()
        if bself.wantToCreateNewTab then
            bself:wantToCreateNewTab();
            bself.tableView:reloadData();
        end
    end
    self:navigationItem():setLeftBarButtonItem(self.addNewTabBtn);
    
    self.tableView = UITableView:createWithStyle(0):retain();
    self.tableView:setFrame(self:view():bounds());
    self.tableView:setAutoresizingMask(math::bor(UIViewAutoresizingFlexibleWidth, UIViewAutoresizingFlexibleHeight));
    self:view():addSubview(self.tableView);
    
    local tableViewDataSource = {};
    function tableViewDataSource:numberOfRowsInSection()
        return #bself.browserList;
    end
    function tableViewDataSource:cellForRowAtIndexPath(tableView, indexPath)
        local cell = tableView:dequeueReusableCellWithIdentifier("__id");
        local closeButton = nil;
        local titleLabel = nil;
        if not cell then
            cell = UITableViewCell:create("__id");
            cell:textLabel():setFont(UIFont:create(14));
            cell:textLabel():setBackgroundColor(UIColor:clearColor());
            --cell:setAccessoryType(1);
            local backgroundView = UIView:create();
            cell:setBackgroundView(backgroundView);
            
            closeButton = UIButton:create("", 0);
            closeButton:setImage(UIImage:imageWithResName("delete_tab.png"));
            local _, _, width, _ = cell:contentView():bounds();
            closeButton:setFrame(width - 60, 0, 60, 60);
            closeButton:setTag(1001);
            closeButton:setAutoresizingMask(UIViewAutoresizingFlexibleLeftMargin);
            --cell:contentView():addSubview(closeButton);
            
            titleLabel = UILabel:create();
            titleLabel:setTag(1002);
            titleLabel:setFrame(5, 0, width - 60, 60);
            titleLabel:setAutoresizingMask(UIViewAutoresizingFlexibleWidth);
            cell:contentView():addSubview(titleLabel);
        else
            closeButton = cell:viewWithTag(1001, UIButton);
            titleLabel = cell:viewWithTag(1002, UILabel);
        end
        --closeButton:setAssociatedObject(tostring(indexPath:row()));
        local tmpViewController = bself.browserList[indexPath:row() + 1];
        titleLabel:setText(tmpViewController:title());
        if indexPath:row() == bself.selectedIndex then
            cell:backgroundView():setBackgroundColor(UIColor:create(240, 240, 240));
        else
            cell:backgroundView():setBackgroundColor(UIColor:create(255, 255, 255));
        end
        return cell;
    end
    function tableViewDataSource:commitEditingStyle(tableView, editingStyle, indexPath)
        if editingStyle == 1 then
            bself:removeTabAtIndexPath(indexPath);
        end
    end
    self.tableView:setDataSource(tableViewDataSource);
    
    local tableViewDelegate = {};
    function tableViewDelegate:didSelectRowAtIndexPath(tableView, indexPath)
        tableView:deselectRowAtIndexPath(indexPath);
        if bself.didSelectedTabIndex then
            bself:didSelectedTabIndex(indexPath:row());
            if bself.didDone then
                bself:didDone();
            end
        end
    end
    function tableViewDelegate:heightForRowAtIndexPath()
        return 60.0;
    end
    self.tableView:setDelegate(tableViewDelegate);
    
    self.browserTitleUpdateObserver = NotificationObserver:create():retain();
    self.browserTitleUpdateObserver:observe("BROWSER_TITLE_UPDATE");
    function self.browserTitleUpdateObserver:didReceive()
        bself.tableView:reloadData();
    end
end

function BrowserTabListController:removeTabAtIndexPath(indexPath)
    if #self.browserList == 1 then
        if self.wantToRemoveTabAtIndex then
            self:wantToRemoveTabAtIndex(indexPath:row());
            self.tableView:reloadData();
        end
        else
        self.tableView:beginUpdates();
        if self.wantToRemoveTabAtIndex then
            self:wantToRemoveTabAtIndex(indexPath:row());
            --bself.tableView:reloadData();
        end
        self.tableView:deleteRowsAtIndexPaths(NSArray:arrayWithObject(indexPath));
        self.tableView:endUpdates();
    end
end

function closeButtonCallback(obj, category)
    globalSelf:removeTabAtIndexPath(NSIndexPath:create(tonumber(obj), 0));
end
