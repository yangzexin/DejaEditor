require "UIKit"
require "MiniBrowserController"
require "BrowserTabListController"

BrowserViewController = {};
BrowserViewController.__index = BrowserViewController;
setmetatable(BrowserViewController, UITabBarController);

function BrowserViewController:create()
    local tmpTabBarController = UITabBarController:create();
    setmetatable(tmpTabBarController, self);
    tmpTabBarController:setViewControllers(NSArray:arrayWithObject(tmpTabBarController:createMiniBrowserController()));
    
    return tmpTabBarController;
end

function BrowserViewController:quit(background)
    
end

function BrowserViewController:newTab()
	local newVCs = NSMutableArray:create(self:viewControllers());
            newVCs:addObject(self:createMiniBrowserController());
            self:setViewControllers(newVCs);
end

function BrowserViewController:switchToTab(index)
	self.browserList[index+1].tabIndex = index;
	self:setSelectedIndex(index);
end

function BrowserViewController:removeTab(idx)
	local nextidx=idx-1;
	if nextidx<0 then
		nextidx=0;
	end
	if #self.browserList == 1 then
		self:newTab();
        end
	self.browserList[idx + 1]:release();
	table.remove(self.browserList, idx + 1);
	for i=1,#self.browserList do
		self.browserList[i].tabIndex=i-1;
	end
	local newVCs = NSMutableArray:create(self:viewControllers());
	newVCs:removeObjectAtIndex(idx);
	self:setViewControllers(newVCs);
	self:switchToTab(nextidx);
end

function BrowserViewController:createMiniBrowserController(initURLString)
    local bself = self;
    if not self.browserList then
        self.browserList = {};
    end
    local tmpVC = MiniBrowserController:create(kTitleBlank):retain();
    tmpVC.initURLString = initURLString;
    self.browserList[#self.browserList + 1] = tmpVC;
    tmpVC:setHidesBottomBarWhenPushed(true);
    local tmpNC = UINavigationController:create(tmpVC);
    function tmpVC:viewDidPop()
        tmpVC:release();
    end
    function tmpVC:wantToClosePopover()
	if bself.popoverController then
		bself.popoverController:dismiss(true);
		bself.popoverController:release();
		bself.popoverController = nil;
	end
    end
    function tmpVC:wantToQuitBrowser(background)
        bself:dismissViewController(true);
	self:wantToClosePopover();
        if not background then
            for i = 1, #bself.browserList do
                bself.browserList[i]:release();
            end
            bself.browserList = nil;
        end
        bself:quit(background);
    end
    function tmpVC:wantToCreateNewBrowser(srcBrowserVC, initURLString, autoselect)
        local newVCs = NSMutableArray:create(bself:viewControllers());
        newVCs:addObject(bself:createMiniBrowserController(initURLString));
        bself:setViewControllers(newVCs);
        bself:switchToTab(newVCs:count() - 1);
    end
	function tmpVC:switchTab(index)
		bself:switchToTab(index);
	end
	function tmpVC:closeTab(index)
		bself:removeTab(index);
	end
    function tmpVC:wantToSwitchTabs(srcBrowserVC, barButtonItem)
	if SystemUtils.isPad() and bself.popoverController and bself.popoverController:popoverVisible() then
		return;
	end
        local tabListVC = BrowserTabListController:create("Tabs"):retain();
        tabListVC.selectedIndex = bself:selectedIndex();
        
        function tabListVC:didSelectedTabIndex(idx)
		bself:switchToTab(idx);
        end
        function tabListVC:wantToCreateNewTab()
        	bself:newTab();
        end
        function tabListVC:wantToRemoveTabAtIndex(idx)
            bself:removeTab(idx);
        end
        function tabListVC:didDone()
            if SystemUtils.isPad() then
		if bself.popoverController then
               		bself.popoverController:dismiss(true);
                	bself.popoverController:release();
                	bself.popoverController = nil;
                	tabListVC:release();
		end
            else
                tabListVC:dismissViewController(true);
                tabListVC:release();
            end
        end
        tabListVC.browserList = bself.browserList;
        local tabListNC = UINavigationController:create(tabListVC);
        if SystemUtils.isPad() then
            bself.popoverController = UIPopoverController:create(tabListNC):retain();
            tabListVC:setContentSizeForViewInPopover(300, 400);
            bself.popoverController:setPopoverContentSize(300, 400);
            bself.popoverController:presentFromBarButtonItem(barButtonItem, 1, true);
            function bself.popoverController:didDismiss()
                tabListVC:didDone();
            end
        else
        	srcBrowserVC:presentViewController(tabListNC, true);
        end
    end
    function tmpVC:numberOfTabs()
        return #bself.browserList;
    end
    return tmpNC;
end