require "UIKit"
require "MiniBrowserController"
require "BrowserTabListController"

BrowserViewController = {};
BrowserViewController.__index = BrowserViewController;
setmetatable(BrowserViewController, UITabBarController);

function BrowserViewController:create()
    local tmpTabBarController = UITabBarController:create();
    setmetatable(tmpTabBarController, self);
    tmpTabBarController:setViewControllers(NSArray:arrayWithObject(tmpTabBarController:createMiniBrowserController()));
    
    return tmpTabBarController;
end

function BrowserViewController:quit(background)
    
end

function BrowserViewController:createMiniBrowserController(initURLString)
    local bself = self;
    if not self.browserList then
        self.browserList = {};
    end
    local tmpVC = MiniBrowserController:create(kTitleBlank):retain();
    tmpVC.initURLString = initURLString;
    self.browserList[#self.browserList + 1] = tmpVC;
    tmpVC:setHidesBottomBarWhenPushed(true);
    local tmpNC = UINavigationController:create(tmpVC);
    function tmpVC:viewDidPop()
        tmpVC:release();
    end
    function tmpVC:wantToClosePopover()
	if bself.popoverController then
		bself.popoverController:dismiss(true);
		bself.popoverController:release();
		bself.popoverController = nil;
	end
    end
    function tmpVC:wantToQuitBrowser(background)
        bself:dismissViewController(true);
	self:wantToClosePopover();
        if not background then
            for i = 1, #bself.browserList do
                bself.browserList[i]:release();
            end
            bself.browserList = nil;
        end
        bself:quit(background);
    end
    function tmpVC:wantToCreateNewBrowser(srcBrowserVC, initURLString, autoselect)
        local newVCs = NSMutableArray:create(bself:viewControllers());
        newVCs:addObject(bself:createMiniBrowserController(initURLString));
        bself:setViewControllers(newVCs);
        bself:setSelectedIndex(newVCs:count() - 1);
    end
    function tmpVC:wantToSwitchTabs(srcBrowserVC, barButtonItem)
	if SystemUtils.isPad() and bself.popoverController and bself.popoverController:popoverVisible() then
		return;
	end
        local tabListVC = BrowserTabListController:create("Tabs"):retain();
        tabListVC.selectedIndex = bself:selectedIndex();
        
        function tabListVC:didSelectedTabIndex(idx)
            bself:setSelectedIndex(idx);
        end
        function tabListVC:wantToCreateNewTab()
            local newVCs = NSMutableArray:create(bself:viewControllers());
            newVCs:addObject(bself:createMiniBrowserController());
            bself:setViewControllers(newVCs);
        end
        function tabListVC:wantToRemoveTabAtIndex(idx)
            if #bself.browserList == 1 then
                self:wantToCreateNewTab();
            end
            local newVCs = NSMutableArray:create(bself:viewControllers());
            newVCs:removeObjectAtIndex(idx);
            bself:setViewControllers(newVCs);
            bself.browserList[idx + 1]:release();
            table.remove(bself.browserList, idx + 1);
        end
        function tabListVC:didDone()
            if SystemUtils.isPad() then
		if bself.popoverController then
               		bself.popoverController:dismiss(true);
                	bself.popoverController:release();
                	bself.popoverController = nil;
                	tabListVC:release();
		end
            else
                tabListVC:dismissViewController(true);
                tabListVC:release();
            end
        end
        tabListVC.browserList = bself.browserList;
        local tabListNC = UINavigationController:create(tabListVC);
        if SystemUtils.isPad() then
            bself.popoverController = UIPopoverController:create(tabListNC):retain();
            tabListVC:setContentSizeForViewInPopover(300, 400);
            bself.popoverController:setPopoverContentSize(300, 400);
            bself.popoverController:presentFromBarButtonItem(barButtonItem, 1, true);
            function bself.popoverController:didDismiss()
                tabListVC:didDone();
            end
        else
        	srcBrowserVC:presentViewController(tabListNC, true);
        end
    end
    function tmpVC:numberOfTabs()
        return #bself.browserList;
    end
    return tmpNC;
end