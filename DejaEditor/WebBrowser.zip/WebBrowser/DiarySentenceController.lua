require "UIKit"
require "Net"
require "Media"
require "Utils"

class(DiarySentenceController, UIViewController);

function DiarySentenceController:shouldAutorotate()
    return true;
end

function DiarySentenceController:viewDidLoad()
    self:readSentenceList();
    self.sentenceInfo = {};
    
    local bself = self;
    local x, y, width, height = self:view():bounds();
    height = 120;
    local headerView = UIView:create();
    headerView:setFrame(0, 0, width, height);
    headerView:setAutoresizingMask(UIViewAutoresizingFlexibleWidth);
    headerView:setBackgroundColor(UIColor:create(0, 172, 192));

    self.textLabel = UILabel:create():retain();
    self.textLabel:setFont(UIFont:create(14, true));
    self.textLabel:setFrame(10, 10, width - 90, height - 20);
    self.textLabel:setNumberOfLines(0);
    self.textLabel:setTextColor(UIColor:create(255, 255, 255));
    --self.textLabel:setBackgroundColor(UIColor:create(0, 0, 0));
    headerView:addSubview(self.textLabel);
    
    self.playButton = UIButton:create("播放🎺", 0):retain();
    self.playButton:setFrame(width - 70, 0, 60, height - 20);
    self.playButton:setHidden(true);
    self.playButton:setAutoresizingMask(UIViewAutoresizingFlexibleLeftMargin);
    headerView:addSubview(self.playButton);
    function self.playButton:didTap()
        self:setEnabled(false);
        local buttonSelf = self;
        
        local audioCachePath = audioCacheForAudioURL(bself.sentenceInfo.audioURL);
        if audioCachePath then
            print("sound cache exists:"..audioCachePath);
            playAudioAtPath(audioCachePath, function() buttonSelf:setEnabled(true); end);
            return;
        end
        local downloader = HTTPRequest:download(bself.sentenceInfo.audioURL);
        function downloader:progress(downloaded, total)
            --print(downloaded, total);
        end
        function downloader:response(tmpFilePath, err)
            --print(tmpFilePath, err);
            if ustring::length(tmpFilePath) ~= 0 then
                print("play:"..tmpFilePath);
                
                local audioPath = moveAudioToCache(bself.sentenceInfo.audioURL, tmpFilePath);
                playAudioAtPath(audioPath, function() buttonSelf:setEnabled(true); end);
            end
        end
    end
    
    self.tableView = UITableView:create():retain();
    self.tableView:setFrame(self:view():bounds());
    self.tableView:setAutoresizingMask(math::bitOr(UIViewAutoresizingFlexibleWidth, UIViewAutoresizingFlexibleHeight));
    self:view():addSubview(self.tableView);
    local tmpHeaderView = UIView:create();
    tmpHeaderView:setFrame(0, 0, 320, height);
    self.tableView:setTableHeaderView(tmpHeaderView);
    self:view():addSubview(headerView);
    
    self:setWaiting(true);
    self.httpReq = HTTPRequest:get("http://dict.cn");
    function self.httpReq:response(res, err)
        bself:setWaiting(false);
        if ustring::length(res) ~= 0 then
            local beginIndex = ustring::find(res, "<div class=\"daily_sentence\">");
            local endIndex = ustring::find(res, "</div>", beginIndex);
            --print(beginIndex, endIndex);
            local usableStr = ustring::substring(res, beginIndex, endIndex);
            --NSLog(usableStr);
            
            local audioBeignIndex = ustring::find(usableStr, "audio=\"") + 7;
            local audioEndIndex = ustring::find(usableStr, "\"", audioBeignIndex);
            local audioDate = ustring::substring(usableStr, audioBeignIndex, audioEndIndex);
            local audioURL = "http://audio.dict.cn/audio/"..audioDate..".mp3";
            --print(audioURL);
            bself.sentenceInfo.audioURL = audioURL;
            
            local textEndIndex = ustring::find(usableStr, "</a>", ustring::length(usableStr) - 1, 1);
            local textBeginIndex = ustring::find(usableStr, ">", textEndIndex, 1);
            local text = ustring::substring(usableStr, textBeginIndex + 1, textEndIndex);
            --print(textBeginIndex, textEndIndex);
            text = ustring::replace(text, "&nbsp;&nbsp;", "\n");
            --print(text);
            bself.sentenceInfo.text = text;
            
            bself.textLabel:setText(text);
            bself.playButton:setHidden(false);
            bself:saveSentence(text, audioURL);
        else
            ui::dialog("网络连接失败", "", "好");
        end
    end
    
    local tableViewDataSource = {};
    function tableViewDataSource:numberOfRowsInSection()
        if bself.sentenceList then
            return bself.sentenceList:count();
        end
        return 0;
    end
    function tableViewDataSource:cellForRowAtIndexPath(tableView, indexPath)
        local cell = tableView:dequeueReusableCellWithIdentifier("__id");
        if not cell then
            cell = UITableViewCell:create("__id");
            cell:textLabel():setFont(UIFont:create(14.0));
        end
        local dict = bself.sentenceList:objectAtIndex(bself.sentenceList:count() - indexPath:row() - 1);
        setmetatable(dict, NSDictionary);
        cell:textLabel():setText(dict:objectForKey("date").." "..StringUtils.trim(StringUtils.removeUnicodeCharsFromString(dict:objectForKey("text"))));
        return cell;
    end
    self.tableView:setDataSource(tableViewDataSource);
    
    local tableViewDelegate = {};
    function tableViewDelegate:didSelectRowAtIndexPath(tableView, indexPath)
        tableView:deselectRowAtIndexPath(indexPath);
        local dict = bself.sentenceList:objectAtIndex(bself.sentenceList:count() - indexPath:row() - 1);
        setmetatable(dict, NSDictionary);
        bself.sentenceInfo.audioURL = dict:objectForKey("audioURL");
        bself.sentenceInfo.text = dict:objectForKey("text");
        bself.textLabel:setText(bself.sentenceInfo.text);
        bself.playButton:setHidden(false);
    end
    self.tableView:setDelegate(tableViewDelegate);
end

function cachePath()
	local path = StringUtils.appendingPathComponent(FileUtils.documentPath(), "imyvoa_caches");
	if not FileUtils.exists(path) then
		FileUtils.createDirectory(path);
	end
    return path;
end

function sentenceListPath()
    return StringUtils.appendingPathComponent(cachePath(), "sentencs_list.txt");
end

function DiarySentenceController:sentenceExistsToday()
    local today = DateUtils.now("yyyy-MM-dd");
    for i = 0, self.sentenceList:count() - 1 do
        local dict = self.sentenceList:objectAtIndex(i);
        setmetatable(dict, NSDictionary);
        local date = dict:objectForKey("date");
        if today == date then
            return true;
        end
    end
    
    return false;
end

function DiarySentenceController:compareWithLastDay(sentence)
    if self.sentenceList:count() ~= 0 then
        sentence = StringUtils.trim(StringUtils.removeUnicodeCharsFromString(sentence));
        lastDay = self.sentenceList:objectAtIndex(0);
        setmetatable(lastDay, NSDictionary);
        local lastSentence = lastDay:objectForKey("text");
        lastSentence = StringUtils.trim(StringUtils.removeUnicodeCharsFromString(lastSentence));
        local equals = StringUtils.equals(sentence, lastSentence);
        return equals;
    end
    return false;
end

function DiarySentenceController:saveSentence(text, audioURL)
    local today = DateUtils.now("yyyy-MM-dd");
    if self:sentenceExistsToday() then
        print(today.." exists");
        return;
    elseif self:compareWithLastDay(text) then
        print(text.." exists");
        return;
    end
    local dict = NSMutableDictionary:create();
    dict:setObjectForKey(text, "text");
    dict:setObjectForKey(audioURL, "audioURL");
    dict:setObjectForKey(today, "date");
    self.sentenceList:addObject(dict);
    print("saving:"..today);
    self:saveSentenceList();
    self.tableView:reloadData();
end

function DiarySentenceController:readSentenceList()
    local arr = NSMutableArray:read(sentenceListPath());
    if arr then
        self.sentenceList = arr:retain();
    else
        self.sentenceList = NSMutableArray:create():retain();
    end
end

function DiarySentenceController:saveSentenceList()
    self.sentenceList:writeToFile(sentenceListPath());
end

function moveAudioToCache(audioURL, tmpAudioPath)
    local audioMD5 = StringUtils.md5(audioURL);
    local audioCachePath = StringUtils.appendingPathComponent(cachePath(), "sentense_audio_cache");
    if not FileUtils.exists(audioCachePath) then
        FileUtils.createDirectory(audioCachePath, true);
    end
    local audioPath = StringUtils.appendingPathComponent(audioCachePath, audioMD5);
    FileUtils.move(tmpAudioPath, audioPath);
    return audioPath;
end

function audioCacheForAudioURL(audioURL)
    local audioMD5 = StringUtils.md5(audioURL);
    local audioCachePath = StringUtils.appendingPathComponent(cachePath(), "sentense_audio_cache");
    local audioPath = StringUtils.appendingPathComponent(audioCachePath, audioMD5);
    if FileUtils.exists(audioPath) then
        return audioPath;
    end
    return nil;
end

function playAudioAtPath(tmpFilePath, playFinishFunc)
    local player = AVAudioPlayer:create(NSURL:create(tmpFilePath, true));
    if not player then
        ui::dialog("播放失败，错误-1001", "", "确定");
        playFinishFunc();
        return;
    end
    player:retain();
    player:play();
    function player:didFinishPlaying()
        playFinishFunc();
        player:release();
    end
end
