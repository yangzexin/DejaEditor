require "FMDatabase"
require "FileUtils"
require "DiarySentenceController"

class(HistoryManager);
class(HistoryItem);

function HistoryManager:init()
	super:init();
	local path = string::invokeMethod(cachePath(), 
		"stringByAppendingPathComponent:", "history_manager.db");
	local dbExists = FileUtils.exists(path);
	self.db = FMDatabase:databaseWithPath(path):retain();
	self.db:open();
	if not dbExists then
		local sql = [===[
			create table history_list(
				uid Integer primary key autoincrement,
				title text,
				url text
			);
		]===];
		local success = self.db:executeUpdate(sql);
		if success then
			utils::log("create table success");
		else
			utils::log("create table failed");
		end
	end
end

function HistoryManager:historyList(prefix, pageIndex, numItemsInPage)
	if pageIndex == nil then
		pageIndex = 1;
	end
	if numItemsInPage == nil then
		numItemsInPage = 20;
	end
	pageIndex = pageIndex -1;
	local sql = "select title, url from history_list where url like '%"..prefix.."%'   order by uid desc limit "..
		(pageIndex * numItemsInPage)..","..numItemsInPage;
	--utils::log(sql);
	local rs = self.db:executeQuery(sql);
	local list = {};
	while rs:next() do
		local hi = HistoryItem:new();
		hi:setTitle(rs:stringForColumn("title"));
		hi:setUrl(rs:stringForColumn("url"));
		if StringUtils.length(StringUtils.trim(hi:title()))  ~= 0 
			and StringUtils.length(StringUtils.trim(hi:url()))  ~= 0 then
			list[#list + 1] = hi;
		end
	end
	return list;
end

function HistoryManager:addHistory(title, url)
	local hid = self:firstHistoryId(title, url);
	if hid then
		local sql = "delete from history_list where uid="..hid;
		self.db:executeUpdate(sql);
	end
	local sql = "insert into history_list(title, url) values('"..title.."', '"..url.."')";
	--utils::log(sql);
	self.db:executeUpdate(sql);
end

function HistoryManager:historyExists(title, url)
	local sql = "select title from history_list where title='"..title.."' and url='"..url.."'";
	--utils::log(sql);
	local rs = self.db:executeQuery(sql);
	if rs:next() then
		return true;
	end
	return false;
end

function HistoryManager:firstHistoryId(title, url)
	local sql = "select uid from history_list where title='"..title.."' and url='"..url.."'";
	--utils::log(sql);
	local rs = self.db:executeQuery(sql);
	if rs:next() then
		return rs:stringForColumn("uid");
	end
	return nil;
end

function HistoryManager:clear()
	
end

function HistoryManager:dealloc()
	super:dealloc();
	self.db:close();
end

function HistoryItem:init()
	super:init();
	self._title = "";
	self._url = "";
end

function HistoryItem:title()
	return self._title;
end

function HistoryItem:setTitle(title)
	self._title = title;
end

function HistoryItem:url()
	return self._url;
end

function HistoryItem:setUrl(url)
	self._url = url;
end

function HistoryItem:dealloc()
	super:dealloc();
end