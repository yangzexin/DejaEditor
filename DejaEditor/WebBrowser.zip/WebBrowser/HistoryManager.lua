require "FMDatabase"
require "FileUtils"
require "DiarySentenceController"

class(HistoryManager);
class(HistoryItem);

function HistoryManager:init()
	super:init();
	local path = string::invokeMethod(cachePath(), 
		"stringByAppendingPathComponent:", "history_manager.db");
	local dbExists = FileUtils.exists(path);
	self.db = FMDatabase:databaseWithPath(path):retain();
	self.db:open();
	if not dbExists then
		local sql = [===[
			create table history_list(
				uid Integer primary key autoincrement,
				title text,
				url text
			);
		]===];
		local success = self.db:executeUpdate(sql);
		if success then
			utils::log("create table success");
		else
			utils::log("create table failed");
		end
	end
end

function HistoryManager:historyList(prefix)
	
end

function HistoryManager:addHistory(title, url)
	
end

function HistoryManager:clear()
	
end

function HistoryManager:dealloc()
	super:dealloc();
	utils::log("test");
end

function HistoryItem:init()
	super:init();
	self._title = "";
	self._url = "";
end

function HistoryItem:title()
	return self._title;
end

function HistoryItem:setTitle(title)
	self._title = title;
end

function HistoryItem:url()
	return self._url;
end

function HistoryItem:setUrl(url)
	self._url = url;
end

function HistoryItem:dealloc()
	super:dealloc();
end