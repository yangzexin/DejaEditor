require "UIKit"
require "Utils"
require "HistoryManager"

MiniBrowserController = {};
MiniBrowserController.__index = MiniBrowserController;
setmetatable(MiniBrowserController, UIViewController);

local kTitleBlank = "无标题";

function MiniBrowserController:dealloc()
    self:releaseFields();
    UIViewController.dealloc(self);
end

function MiniBrowserController:viewWillAppear()
    self:navigationController():setNavigationBarHidden(true);
    --self.switchTabBtn:setTitle("Tabs("..self:numberOfTabs()..")");
    if SystemUtils.isPad() then
        self:navigationController():navigationBar():setBarStyle(1);
        self.topBar:setBarStyle(1);
        self:navigationController():toolbar():setBarStyle(1);
    end
end

function MiniBrowserController:recycle()
    self:dismissViewController(true);
    self:release();
end

function MiniBrowserController:updateBrowserStates()
    self.addressField:setText(self.webView:currentDocumentURL():absoluteString());
    self.pageTitleLabel:setText(self.webView:currentPageTitle());
    self:setTitle(self.pageTitleLabel:text());
    NSNotificationCenter.postNotificationName("BROWSER_TITLE_UPDATE");
    self.webView:disableContextMenu();
    self.backBtn:setEnabled(self.webView:canGoBack());
    self.forwardBtn:setEnabled(self.webView:canGoForward());
end

function MiniBrowserController:setWaiting(waiting)
    local img = nil;
    if waiting then
        img = self.stopImage;
    else
        img = self.refreshImage;
    end
    self.refreshButton:setImage(img);
    self.waiting = waiting;
end

function MiniBrowserController:showSelectLinkDialog(URLString)
    local bself = self;
    if self.selectLinkDialog then
        self.selectLinkDialog:release();
        self.selectLinkDialog = nil;
    end
    self.selectLinkDialog = UIDialog:create("", URLString, "取消", "打开", "新标签中打开", "复制"):retain();
    function self.selectLinkDialog:dismiss(buttonIndex, buttonTitle)
        if buttonIndex == 0 then
            
        elseif buttonIndex == 1 then
            print(URLString);
            print(bself.webView);
            bself.webView:loadURLString(URLString);
        elseif buttonIndex == 2 then
            bself:wantToCreateNewBrowser(bself, URLString, true);
        elseif buttonIndex == 3 then
            local pasteboard = runtime::invokeClassMethod("UIPasteboard", "generalPasteboard");
            runtime::invokeMethod(pasteboard, "setString", URLString);
            runtime::releaseObject(pasteboard);
        end
    end
end

function MiniBrowserController:viewDidLoad()
    local bself = self;
    self:setTitle(kTitleBlank);
    self.historyManager = HistoryManager:new():retain();
	
    local _, _, viewWidth, viewHeight = self:view():bounds();
    
    bself.webViewContainer = UIView:create();
    bself.webViewContainer:setFrame(self:view():bounds());
    bself.webViewContainer:setAutoresizingMask(math::bor(UIViewAutoresizingFlexibleWidth, UIViewAutoresizingFlexibleHeight));
    bself:view():addSubview(bself.webViewContainer);
    
    bself.topBar = UINavigationBar:create():retain();
    bself.topBar:setAutoresizingMask(UIViewAutoresizingFlexibleWidth);
    bself.topBar:setFrame(0, 0, viewWidth, 59);
    bself.cancelNaviItem = UINavigationItem:create():retain();
    bself.cancelAddressFieldBtn = UIBarButtonItem:create("取消"):retain();
    bself.cancelAddressFieldBtn:setStyle(2);
    function bself.cancelAddressFieldBtn:tapped()
        bself.addressField:resignFirstResponder();
    end
    bself.cancelNaviItem:setRightBarButtonItem(bself.cancelAddressFieldBtn);
    
    bself.webView = UIWebView:create():retain();
    bself.webView:setFrame(0, 0, viewWidth, viewHeight);
    bself.webView:setAutoresizingMask(math::bor(UIViewAutoresizingFlexibleWidth, UIViewAutoresizingFlexibleHeight));
    bself.webView:setScalesPageToFit(true);
    --bself:view():addSubview(bself.webView);
    bself.webViewContainer:addSubview(bself.webView);
    if self.initURLString then
        self.webView:loadURLString(self.initURLString);
    end
    
    bself.gr = UIGestureRecognizer:create(UILongPressGestureRecognizer):retain();
    --bself.webView:addGestureRecognizer(bself.gr);
    bself.webViewContainer:addGestureRecognizer(bself.gr);
    function self.gr:action()
        if self:state() == 1 then
            local pointx, pointy = self:locationInView(self:view());
            local sx, sy = bself.webView:scrollOffset();
            if sy == 0 then
                pointy = pointy - 60;
            end
            local realWidth, realHeight = bself.webView:realWindowSize();
            local _, _, webViewWidth, webViewHeight = bself.webView:bounds();
            local percent = realWidth / webViewWidth;
            local URLString = bself.webView:linkURLStringAtPoint(pointx * percent, pointy * percent);
            
            if string.len(URLString) ~= 0 then
                bself:showSelectLinkDialog(URLString);
            end
        end
    end
    
    bself.webViewScrollView = bself.webView:scrollView():retain();
    bself.webViewScrollView:setContentInset(60, 0, 0, 0);
    bself.webViewScrollView:setScrollIndicatorInsets(60, 0, 0, 0);
    bself.webViewScrollView:setScrollsToTop(false);
    local scrollViewDelegate = {};
    function scrollViewDelegate:scrollViewDidScroll(scrollView)
        local offsetX, offsetY = scrollView:contentOffset();
        local _, _, topBarWidth, topBarHeight = bself.topBar:bounds();
        if offsetY > -60.0 then
            bself.topBar:setFrame(0, - topBarHeight - offsetY, topBarWidth, topBarHeight);
        else
            bself.topBar:setFrame(0, 0, topBarWidth, topBarHeight);
        end
    end
    bself.webViewScrollView:setDelegate(scrollViewDelegate);
    self:view():addSubview(bself.topBar);
    
    local webViewDelegate = {};
    function webViewDelegate:shouldStartLoadWithRequest(webView, URLString, navigationType)
        if string.len(URLString) == 0 then
            URLString = bself.webView:currentDocumentURL():absoluteString();
        end
        if string.len(URLString) ~= 0 then
            bself.addressField:setText(URLString);
        end
        return true;
    end
    function webViewDelegate:didStartLoad()
        bself:setWaiting(true);
    end
    function webViewDelegate:didFinishLoad()
        bself:setWaiting(false);
        bself:updateBrowserStates();
    end
    function webViewDelegate:didFailLoadWithError(webView, err)
        bself:setWaiting(false);
        local code = err:code();
        if code == -999 then
            print("error code:"..code);
        else
            ui::dialog("加载失败", err:localizedDescription(), "确定");
        end
        bself:updateBrowserStates();
    end
    bself.webView:setDelegate(webViewDelegate);
    
    bself.backBtn = UIBarButtonItem:createWithImage(UIImage:imageWithResName("btn_back.png")):retain();
    bself.backBtn:setEnabled(false);
    function bself.backBtn:tapped()
        bself.webView:goBack();
    end
    bself.forwardBtn = UIBarButtonItem:createWithImage(UIImage:imageWithResName("btn_forward.png")):retain();
    bself.forwardBtn:setEnabled(false);
    function bself.forwardBtn:tapped()
        bself.webView:goForward();
    end
    bself.newTabBtn = UIBarButtonItem:createWithSystemItem(4):retain();
    function bself.newTabBtn:tapped()
        if bself.wantToCreateNewBrowser then
            bself:wantToCreateNewBrowser(bself);
        else
            print("wantToCreateNewBrowser not implemented");
        end
    end
    bself.quitBtn = UIBarButtonItem:create("退出"):retain();
    bself.quitBtn:setStyle(1);
    function bself.quitBtn:tapped()
        bself.quitDialog = UIAlertView:create("", "退出浏览器？", "取消", "退出", "后台运行"):retain();
        function bself.quitDialog:dismiss(buttonIndex)
            local background = true;
            if buttonIndex == 0 then
                return;
            elseif buttonIndex == 1 then
                background = false;
            end
            if bself.wantToQuitBrowser then
                bself:wantToQuitBrowser(background);
            end
        end
    end
    bself.switchTabBtn = UIBarButtonItem:createWithImage(UIImage:imageWithResName("switch.png")):retain();
    function bself.switchTabBtn:tapped()
        if bself.wantToSwitchTabs then
            bself:wantToSwitchTabs(bself, bself.switchTabBtn);
        else
            print("wantToSwitchTabs not implemented");
        end
    end
    
    local items = NSMutableArray:create();
    items:addObject(UIBarButtonItem:createWithSystemItem(5));
    items:addObject(bself.backBtn);
    items:addObject(UIBarButtonItem:createWithSystemItem(5));
    items:addObject(bself.forwardBtn);
    items:addObject(UIBarButtonItem:createWithSystemItem(5));
    --items:addObject(bself.newTabBtn);
    --items:addObject(UIBarButtonItem:createWithSystemItem(5));
    items:addObject(bself.switchTabBtn);
    items:addObject(UIBarButtonItem:createWithSystemItem(5));
    items:addObject(bself.quitBtn);
    self:setToolbarItems(items);
    self:navigationController():setToolbarHidden(false);
    
    bself.pageTitleLabel = UILabel:create("无标题"):retain();
    bself.pageTitleLabel:setFont(UIFont:create(13));
    bself.pageTitleLabel:setTextAlignment(1);
    if SystemUtils.isPad() then
        bself.pageTitleLabel:setTextColor(UIColor:create(255, 255, 255));
    else
        bself.pageTitleLabel:setTextColor(UIColor:create(66, 72, 82));
    end
    bself.pageTitleLabel:setAutoresizingMask(UIViewAutoresizingFlexibleWidth);
    bself.pageTitleLabel:setFrame(0, 4, viewWidth, bself.pageTitleLabel:font():lineHeight());
    bself.topBar:addSubview(bself.pageTitleLabel);
    
    bself.addressFieldBgImgView = UITextField:create():retain();
    bself.addressFieldBgImgView:setFrame(4, 22, viewWidth - 8, 30);
    bself.addressFieldBgImgView:setAutoresizingMask(UIViewAutoresizingFlexibleWidth);
    bself.addressFieldBgImgView:setUserInteractionEnabled(false);
    bself.topBar:addSubview(bself.addressFieldBgImgView);
    
    bself.addressField = UITextField:create():retain();
    bself.addressField:setKeyboardType(UIKeyboardTypeURL);
    bself.addressField:setReturnKeyType(1);
    bself.addressField:setFrame(10, 22, viewWidth - 48, 30);
    bself.addressField:setAutoresizingMask(UIViewAutoresizingFlexibleWidth);
    bself.addressField:setClearButtonMode(1);
    bself.addressField:setFont(UIFont:create(13));
    bself.addressField:setPlaceholder("前往此地址");
    if not bself.initURLString then
        bself.addressField:becomeFirstResponder();
	if bself.wantToClosePopover then
		bself:wantToClosePopover();
	end
    end
    --bself.addressField:setBackgroundColor(UIColor:create(10, 10, 10));
    bself.addressField:setBorderStyle(0);
    bself.topBar:addSubview(bself.addressField);
    local addressFieldDelegate = {};
    function addressFieldDelegate:didBeginEditing()
        bself.topBar:pushNavigationItem(bself.cancelNaviItem, true);
        local anim = UIAnimation:create();
        local _, _, viewWidth, _ = bself:view():bounds();
        bself.addressField:setClearButtonMode(0);
        function anim:animation()
            bself.refreshButton:setFrame(viewWidth - 100, 21, 42, 32);
            bself.addressFieldBgImgView:setFrame(4, 22, viewWidth - 66, 30);
            bself.addressField:setFrame(10, 22, viewWidth - 106, 30);
        end
        function anim:complete()
            bself.addressField:setClearButtonMode(1);
        end
        anim:start();
    end
    function addressFieldDelegate:didEndEditing()
        bself.topBar:popNavigationItem(true);
        local anim = UIAnimation:create();
        local _, _, viewWidth, _ = bself:view():bounds();
        bself.addressField:setClearButtonMode(0);
        function anim:animation()
            bself.refreshButton:setFrame(viewWidth - 42, 21, 42, 32);
            bself.addressFieldBgImgView:setFrame(4, 22, viewWidth - 8, 30);
            bself.addressField:setFrame(10, 22, viewWidth - 48, 30);
        end
        function anim:complete()
            bself.addressField:setClearButtonMode(1);
        end
        anim:start();
    end
    function addressFieldDelegate:shouldReturn()
        local URLString = StringUtils.trim(bself.addressField:text());
        local length = StringUtils.length(URLString);
        
        if length == 0 then
            return;
        end
        if not StringUtils.hasPrefix(URLString, "http://") then
            URLString = "http://"..URLString;
        end
        bself.addressField:setText(URLString);
        bself.webView:loadURLString(URLString);
        return true;
    end
    bself.addressField:setDelegate(addressFieldDelegate);
    
    bself.refreshImage = UIImage:imageWithResName("refresh.png"):retain();
    bself.stopImage = UIImage:imageWithResName("stop.png"):retain();
    bself.refreshButton = UIButton:create("", 0):retain();
    bself.refreshButton:setFrame(viewWidth - 42, 21, 42, 32);
    bself.refreshButton:setImage(bself.refreshImage);
    bself.refreshButton:setImageEdgeInsets(0, 5, 0, 0);
    --bself.refreshButton:setBackgroundColor(UIColor:create(255, 0, 0));
    bself.refreshButton:setAutoresizingMask(UIViewAutoresizingFlexibleLeftMargin);
    bself.topBar:addSubview(bself.refreshButton);
    function bself.refreshButton:tapped()
        if bself.waiting then
            bself.webView:stopLoading();
        else
            bself.webView:reload();
        end
    end
end

function MiniBrowserController:shouldAutorotate()
    return true;
end