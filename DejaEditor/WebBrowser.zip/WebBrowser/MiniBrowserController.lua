require "UIKit"
require "Utils"
require "HistoryManager"
require "NSURL"
require "NSURLRequest"
require "TabSwitchView"
require "UIActionSheet"
require "BookmarkManagerController"

class(MiniBrowserController, UIViewController);

local kTitleBlank = "无标题";
local topBarHeight = 100;
function MiniBrowserController:viewWillAppear()
	super:viewWillAppear();
    self:navigationController():setNavigationBarHidden(true);
    --self.switchTabBtn:setTitle("Tabs("..self:numberOfTabs()..")");
	if self.tabIndex == nil then
		self.tabIndex=0;
	end
	self:updateSwitchButtonList();
    if SystemUtils.isPad() then
        self:navigationController():navigationBar():setBarStyle(1);
        self.topBar:setBarStyle(1);
        self:navigationController():toolbar():setBarStyle(1);
    end
	 if not self.initURLString then
		self.initURLString = "";
        	self.addressField:becomeFirstResponder();
		if self.wantToClosePopover then
			self:wantToClosePopover();
		end
    	end
end

function MiniBrowserController:recycle()
    self:dismissViewController(true);
    self:release();
end

function MiniBrowserController:dealloc()
	super:dealloc();
end

function MiniBrowserController:exit()
	if self.bookmarkPopover then
		self.bookmarkPopover:dismiss(false);
	end
end

function MiniBrowserController:newTab()
	self:wantToCreateNewBrowser(bself, nil, true);
end

function MiniBrowserController:switchTab(index)

end

function MiniBrowserController:closeTab(index)

end

function MiniBrowserController:showActionMenu()
	local bself = self;
	if self.actionMenu then
		return ;
	end
	self.actionMenu = UIActionSheet:create("", "添加书签"):retain();
	function self.actionMenu:clickedButtonAtIndex(index)
		if index == 0 then
			local title = bself.pageTitleLabel:text();
			local url = bself.addressField:text();
			if StringUtils.length(title) ~= 0 and StringUtils.length(url)  ~= 0 then
				bself.bookmarkManagerController:addBookmark(title, url);
			end
		end
	end
	function self.actionMenu:didDismissWithButtonIndex(buttonIndex)
		safety_release(bself.actionMenu);
		bself.actionMenu=nil;
	end
	self.actionMenu:showFromBarButtonItem(self.actionButton);
end

function MiniBrowserController:gotoURLWithString(URLString)
	local length = StringUtils.length(URLString);
        self.historyListTableView:setHidden(true);
	self.addressField:resignFirstResponder();
        if length == 0 then
            return;
        end
        if not StringUtils.hasPrefix(URLString, "http://") then
            URLString = "http://"..URLString;
        end
        self.addressField:setText(URLString);
        self.webView:loadURLString(URLString);
end

function MiniBrowserController:updateSwitchButtonList(selectedIndex)
	if not selectedIndex then
		selectedIndex=self.tabIndex;
	end
	local viewControllers = self:tabBarController():viewControllers();
	local titleList = {};
	for i=0,viewControllers:count()-1 do
		local vc = viewControllers:objectAtIndex(i);
		setmetatable(vc, UIViewController);
		titleList[#titleList+1]=vc:title();
	end
	self.tabSwitchView:reset(titleList, selectedIndex);
end

function MiniBrowserController:updateBrowserStates()
	local req = runtime::invokeMethod(self.webView:id(), "request");
	local mainURL = NSURL:get(runtime::invokeMethod(req, "mainDocumentURL"));
	local URLString = mainURL:absoluteString();
	if StringUtils.length(URLString)  ~= 0 then
		self.addressField:setText(URLString);
	end
    self.pageTitleLabel:setText(self.webView:currentPageTitle());
    self:setTitle(self.pageTitleLabel:text());
    NSNotificationCenter.postNotificationName("BROWSER_TITLE_UPDATE");
    self.webView:disableContextMenu();
    self.backBtn:setEnabled(self.webView:canGoBack());
    self.forwardBtn:setEnabled(self.webView:canGoForward());
	if not StringUtils.equals(self.pageTitleLabel:text(), kTitleBlank) 
			and not StringUtils.equals(URLString, self.lastAddURLString) then
		self.lastAddURLString = URLString;
		self.historyManager:addHistory(self.pageTitleLabel:text(), URLString);
	end
end

function MiniBrowserController:setWaiting(waiting)
    local img = nil;
    if waiting then
        img = self.stopImage;
    else
        img = self.refreshImage;
    end
    self.refreshButton:setImage(img);
    self.waiting = waiting;
end

function MiniBrowserController:showSelectLinkDialog(URLString, px, py)
    local bself = self;
    if self.selectLinkDialog then
        self.selectLinkDialog:release();
        self.selectLinkDialog = nil;
    end
    self.selectLinkDialog = UIActionSheet:create(URLString, 
	 "打开", "新标签中打开", "复制", "取消"):retain();
    function self.selectLinkDialog:clickedButtonAtIndex(buttonIndex)
        if buttonIndex == 0 then
            bself:gotoURLWithString(URLString);
        elseif buttonIndex == 1 then
            bself:wantToCreateNewBrowser(bself, URLString, true);
        elseif buttonIndex == 2 then
            local pasteboard = runtime::invokeClassMethod("UIPasteboard", "generalPasteboard");
            runtime::invokeMethod(pasteboard, "setString", URLString);
            runtime::releaseObject(pasteboard);
        end
    end
	local _,_,_,topBarHeight = self.topView:bounds();
	local sx, sy = bself.webView:scrollOffset();
        if sy == 0 then
        	py = py + topBarHeight;
        end
	self.selectLinkDialog:showFromRect(px, py, 0, 0, self:view(), true);
end

function MiniBrowserController:viewDidLoad()
    local bself = self;
    self:setTitle(kTitleBlank);
    self.historyManager = HistoryManager:get():retain();
	
    local _, _, viewWidth, viewHeight = self:view():bounds();
    
    bself.webViewContainer = UIView:create();
    bself.webViewContainer:setFrame(self:view():bounds());
    bself.webViewContainer:setAutoresizingMask(math::bitOr(UIViewAutoresizingFlexibleWidth, UIViewAutoresizingFlexibleHeight));
    bself:view():addSubview(bself.webViewContainer);
    
	bself.topView = UIView:create():retain();
	bself.topView:setAutoresizingMask(2);
	bself.topView:setFrame(0, 0, viewWidth, topBarHeight);
	self:view():addSubview(bself.topView);
	
	self.tabSwitchView = TabSwitchView:create():retain();
	self.tabSwitchView:setFrame(0, 60, viewWidth, 40);
	self.tabSwitchView:setAutoresizingMask(2);
	self.topView:addSubview(self.tabSwitchView);
	function self.tabSwitchView:switchTab(index)
		bself:switchTab(index);
	end
	function self.tabSwitchView:closeTab(index)
		bself:closeTab(index);
	end
	function self.tabSwitchView:newTab()
		bself:newTab();
	end
	
    bself.topBar = UINavigationBar:create():retain();
    bself.topBar:setAutoresizingMask(UIViewAutoresizingFlexibleWidth);
    bself.topBar:setFrame(0, 0, viewWidth, 60);
	bself.topView:addSubview(bself.topBar);
    bself.cancelNaviItem = UINavigationItem:create():retain();
    bself.cancelAddressFieldBtn = UIBarButtonItem:create("取消"):retain();
    bself.cancelAddressFieldBtn:setStyle(2);
    function bself.cancelAddressFieldBtn:didTap()
        bself.addressField:resignFirstResponder();
	bself.historyListTableView:setHidden(true);
    end
    bself.cancelNaviItem:setRightBarButtonItem(bself.cancelAddressFieldBtn);
    
    bself.webView = UIWebView:create():retain();
    bself.webView:setFrame(0, 0, viewWidth, viewHeight);
    bself.webView:setAutoresizingMask(math::bitOr(UIViewAutoresizingFlexibleWidth, UIViewAutoresizingFlexibleHeight));
    bself.webView:setScalesPageToFit(true);
    --bself:view():addSubview(bself.webView);
    bself.webViewContainer:addSubview(bself.webView);
    
    bself.gr = UIGestureRecognizer:create(UILongPressGestureRecognizer):retain();
    --bself.webView:addGestureRecognizer(bself.gr);
    bself.webViewContainer:addGestureRecognizer(bself.gr);
    function self.gr:didPerform()
        if self:state() == 1 then
            local pointx, pointy = self:locationInView(self:view());
            local sx, sy = bself.webView:scrollOffset();
            if sy == 0 then
                pointy = pointy - topBarHeight;
            end
            local realWidth, realHeight = bself.webView:realWindowSize();
            local _, _, webViewWidth, webViewHeight = bself.webView:bounds();
            local percent = realWidth / webViewWidth;
            local URLString = bself.webView:linkURLStringAtPoint(pointx * percent, pointy * percent);
            
            if string.len(URLString) ~= 0 then
                bself:showSelectLinkDialog(URLString, pointx, pointy);
            end
        end
    end
    
    bself.webViewScrollView = bself.webView:scrollView():retain();
    bself.webViewScrollView:setContentInset(topBarHeight, 0, 0, 0);
    bself.webViewScrollView:setScrollIndicatorInsets(topBarHeight, 0, 0, 0);
    bself.webViewScrollView:setScrollsToTop(false);
    local scrollViewDelegate = {};
    function scrollViewDelegate:scrollViewDidScroll(scrollView)
        local offsetX, offsetY = scrollView:contentOffset();
        local _, _, topBarWidth, topBarHeight = bself.topView:bounds();
        if offsetY > - topBarHeight then
            bself.topView:setFrame(0, - topBarHeight - offsetY, topBarWidth, topBarHeight);
        else
            bself.topView:setFrame(0, 0, topBarWidth, topBarHeight);
        end
    end
    bself.webViewScrollView:setDelegate(scrollViewDelegate);
    
    local webViewDelegate = {};
    function webViewDelegate:shouldStartLoadWithRequest(webView, request, navigationType)
	
        --[[if string.len(URLString) == 0 then
            URLString = bself.webView:currentDocumentURL():absoluteString();
        end
        if string.len(URLString) ~= 0 then
            bself.addressField:setText(URLString);
        end]]
        return true;
    end
    function webViewDelegate:didStartLoad()
        bself:setWaiting(true);
	bself.historyListTableView:setHidden(true);
    end
    function webViewDelegate:didFinishLoad()
        bself:setWaiting(false);
        bself:updateBrowserStates();
    end
    function webViewDelegate:didFailLoadWithError(webView, err)
        bself:setWaiting(false);
        local code = err:code();
        if code == -999 then
            print("error code:"..code);
        else
            ui::dialog("加载失败", err:localizedDescription(), "确定");
        end
        bself:updateBrowserStates();
    end
    bself.webView:setDelegate(webViewDelegate);
    
    bself.backBtn = UIBarButtonItem:createWithImage(UIImage:imageWithResName("btn_back.png")):retain();
    bself.backBtn:setEnabled(false);
    function bself.backBtn:didTap()
        bself.webView:goBack();
    end
    bself.forwardBtn = UIBarButtonItem:createWithImage(UIImage:imageWithResName("btn_forward.png")):retain();
    bself.forwardBtn:setEnabled(false);
    function bself.forwardBtn:didTap()
        bself.webView:goForward();
    end
    bself.newTabBtn = UIBarButtonItem:createWithSystemItem(4):retain();
    function bself.newTabBtn:didTap()
        if bself.wantToCreateNewBrowser then
            bself:wantToCreateNewBrowser(bself);
        else
            print("wantToCreateNewBrowser not implemented");
        end
    end
    bself.quitBtn = UIBarButtonItem:create("退出"):retain();
    bself.quitBtn:setStyle(2);
    function bself.quitBtn:didTap()
        bself.quitDialog = UIAlertView:create("", "退出浏览器？", "取消", "后台运行", "退出"):retain();
        function bself.quitDialog:didDismiss(buttonIndex)
            local background = true;
            if buttonIndex == 0 then
                return;
            elseif buttonIndex == 2 then
                background = false;
            end
		bself:exit();
            if bself.wantToQuitBrowser then
                bself:wantToQuitBrowser(background);
            end
        end
    end
    bself.switchTabBtn = UIBarButtonItem:createWithImage(
	UIImage:imageWithResName("switch.png")):retain();
    function bself.switchTabBtn:didTap()
        if bself.wantToSwitchTabs then
            bself:wantToSwitchTabs(bself, bself.switchTabBtn);
        else
            print("wantToSwitchTabs not implemented");
        end
    end

	self.actionButton = UIBarButtonItem:createWithSystemItem(9):retain();
	function self.actionButton:didTap()
		bself:showActionMenu();
	end
	bself.bookmarkManagerController = BookmarkManagerController:create(""):retain();
	function bself.bookmarkManagerController:doneButtonTapped()
		if SystemUtils.isPad() then
			bself.bookmarkPopover:dismiss(true);
		else
			bself:dismissViewController(true);
		end
	end
	function self.bookmarkManagerController:didSelectBookmark(title, url)
		bself:gotoURLWithString(url);
		bself.bookmarkPopover:dismiss(true);
	end
	bself.bookmarkManagerController:setTitle("Bookmarks");
	bself.bookmarkManagerNC = UINavigationController:create(
		bself.bookmarkManagerController):retain();
    	bself.bookmarkBtn = UIBarButtonItem:createWithSystemItem(11):retain();
	function bself.bookmarkBtn:didTap()
		if SystemUtils.isPad() then
			if bself.bookmarkPopover then
				if bself.bookmarkPopover:popoverVisible() then
					return ;
				end
			else
				bself.bookmarkPopover = UIPopoverController:create(
					bself.bookmarkManagerNC):retain();
				bself.bookmarkPopover:setPopoverContentSize(320, 480);
			end
			bself.bookmarkPopover:presentFromBarButtonItem(bself.bookmarkBtn, 1, true);
		else
			bself:presentViewController(bself.bookmarkManagerNC, true);
		end
		
	end
    local items = NSMutableArray:create();
    --items:addObject(UIBarButtonItem:createWithSystemItem(5));
    items:addObject(bself.backBtn);
    items:addObject(UIBarButtonItem:createWithSystemItem(5));
    items:addObject(bself.forwardBtn);
    items:addObject(UIBarButtonItem:createWithSystemItem(5));
    items:addObject(self.actionButton);
    items:addObject(UIBarButtonItem:createWithSystemItem(5));
    items:addObject(bself.bookmarkBtn);
    items:addObject(UIBarButtonItem:createWithSystemItem(5));
    items:addObject(bself.quitBtn);
    self:setToolbarItems(items);
    self:navigationController():setToolbarHidden(false);
    
    bself.pageTitleLabel = UILabel:create("无标题"):retain();
    bself.pageTitleLabel:setFont(UIFont:create(13));
    bself.pageTitleLabel:setTextAlignment(1);
    if SystemUtils.isPad() then
        bself.pageTitleLabel:setTextColor(UIColor:create(255, 255, 255));
    else
        bself.pageTitleLabel:setTextColor(UIColor:create(66, 72, 82));
    end
    bself.pageTitleLabel:setAutoresizingMask(UIViewAutoresizingFlexibleWidth);
    bself.pageTitleLabel:setFrame(0, 4, viewWidth, bself.pageTitleLabel:font():lineHeight());
    bself.topBar:addSubview(bself.pageTitleLabel);
    
    bself.addressFieldBgImgView = UITextField:create():retain();
    bself.addressFieldBgImgView:setFrame(4, 22, viewWidth - 8, 30);
    bself.addressFieldBgImgView:setAutoresizingMask(UIViewAutoresizingFlexibleWidth);
    bself.addressFieldBgImgView:setUserInteractionEnabled(false);
    bself.topBar:addSubview(bself.addressFieldBgImgView);
    
    bself.addressField = UITextField:create():retain();
    bself.addressField:setKeyboardType(3);
    bself.addressField:setReturnKeyType(1);
    bself.addressField:setFrame(10, 22, viewWidth - 48, 30);
    bself.addressField:setAutoresizingMask(UIViewAutoresizingFlexibleWidth);
    bself.addressField:setClearButtonMode(1);
    bself.addressField:setFont(UIFont:create(13));
    bself.addressField:setPlaceholder("前往此地址");
    --bself.addressField:setBackgroundColor(UIColor:create(10, 10, 10));
    bself.addressField:setBorderStyle(0);
    bself.topBar:addSubview(bself.addressField);
    local addressFieldDelegate = {};
    function addressFieldDelegate:didBeginEditing()
        bself.topBar:pushNavigationItem(bself.cancelNaviItem, true);
        local anim = UIAnimation:create();
        local _, _, viewWidth, _ = bself:view():bounds();
        bself.addressField:setClearButtonMode(0);
        function anim:animation()
            bself.refreshButton:setFrame(viewWidth - 100, 21, 42, 32);
            bself.addressFieldBgImgView:setFrame(4, 22, viewWidth - 66, 30);
            bself.addressField:setFrame(10, 22, viewWidth - 76, 30);
        end
        function anim:didStop()
            bself.addressField:setClearButtonMode(1);
        end
        anim:start();
	bself.refreshButton:setHidden(true);
	bself.historyList = bself.historyManager:historyList(bself.addressField:text());
	bself.historyListTableView:setHidden(false);
	bself.historyListTableView:reloadData();
    end
	function addressFieldDelegate:textDidChange(textField)
		if not bself.historyListTableView:hidden() then
			bself.historyList = bself.historyManager:historyList(bself.addressField:text());
			bself.historyListTableView:reloadData();
		end
		return true;
	end
    function addressFieldDelegate:didEndEditing()
        bself.topBar:popNavigationItem(true);
	bself.historyListTableView:setHidden(true);
        local anim = UIAnimation:create();
        local _, _, viewWidth, _ = bself:view():bounds();
        bself.addressField:setClearButtonMode(0);
        function anim:animation()
            bself.refreshButton:setFrame(viewWidth - 42, 21, 42, 32);
            bself.addressFieldBgImgView:setFrame(4, 22, viewWidth - 8, 30);
            bself.addressField:setFrame(10, 22, viewWidth - 48, 30);
        end
        function anim:didStop()
            bself.addressField:setClearButtonMode(1);
        end
        anim:start();
	bself.refreshButton:setHidden(false);
    end
    function addressFieldDelegate:shouldReturn()
        local URLString = StringUtils.trim(bself.addressField:text());
        bself:gotoURLWithString(URLString);
        return true;
    end
    bself.addressField:setDelegate(addressFieldDelegate);
    
    bself.refreshImage = UIImage:imageWithResName("refresh.png"):retain();
    bself.stopImage = UIImage:imageWithResName("stop.png"):retain();
    bself.refreshButton = UIButton:create("", 0):retain();
    bself.refreshButton:setFrame(viewWidth - 42, 21, 42, 32);
    bself.refreshButton:setImage(bself.refreshImage);
    bself.refreshButton:setImageEdgeInsets(0, 5, 0, 0);
    --bself.refreshButton:setBackgroundColor(UIColor:create(255, 0, 0));
    bself.refreshButton:setAutoresizingMask(UIViewAutoresizingFlexibleLeftMargin);
    bself.topBar:addSubview(bself.refreshButton);
    function bself.refreshButton:didTap()
        if bself.waiting then
            bself.webView:stopLoading();
        else
            bself.webView:reload();
        end
    end

	self.historyListTableView = UITableView:create():retain();
	self.historyListTableView:setAutoresizingMask(
		math::bitOr(UIViewAutoresizingFlexibleWidth, UIViewAutoresizingFlexibleHeight, 8));
	if SystemUtils.isPad() then
		self.historyListTableView:setFrame(0, 60, viewWidth, 220);
	else
		self.historyListTableView:setFrame(0, 0, viewWidth, viewHeight);
	end
	runtime::invokeMethod(self.historyListTableView:id(), "setRowHeight:", 60);
	self:view():addSubview(self.historyListTableView);
	local historyListTableViewDataSource = {};
	function historyListTableViewDataSource:numberOfRowsInSection(tableView, section)
		if bself.historyList then
			return #bself.historyList;
		end
		return 0;
	end
	function historyListTableViewDataSource:cellForRowAtIndexPath(tableView, indexPath)
		local cell = tableView:dequeueReusableCellWithIdentifier("history");
		local urlLabel;
		local titleLabel;
		if not cell then
			cell = UITableViewCell:create("history", 0);
			local cx,cy,cw,ch=cell:contentView():bounds();
			urlLabel= UILabel:create();
			urlLabel:setFont(UIFont:create(16, true));
			urlLabel:setFrame(5, 5, cw-10, urlLabel:font():lineHeight());
			urlLabel:setTag(11);
			urlLabel:setAutoresizingMask(2);
			cell:contentView():addSubview(urlLabel);
			local ux,uy,uw,uh= urlLabel:frame();
			titleLabel = UILabel:create();
			titleLabel:setFont(UIFont:create(14));
			titleLabel:setFrame(5, uy+uh+5, cw-10, titleLabel:font():lineHeight());
			titleLabel:setTag(12);
			titleLabel:setAutoresizingMask(2);
			titleLabel:setTextColor(UIColor:create(29, 131, 240));
			cell:contentView():addSubview(titleLabel);
		else
			titleLabel= cell:contentView():viewWithTag(12, UILabel);
			urlLabel= cell:contentView():viewWithTag(11, UILabel);
		end
		if indexPath:row() < #bself.historyList then
			local hi = bself.historyList[indexPath:row() +1];
			titleLabel:setText(hi:title());
			urlLabel:setText(hi:url());
		else
			cell:textLabel():setTextAlignment(2);
			cell:textLabel():setText("清除历史纪录");
		end
		return cell;
	end
	self.historyListTableView:setDataSource(historyListTableViewDataSource);
	local historyListTableViewDelegate={};
	function historyListTableViewDelegate:didSelectRowAtIndexPath(tableView, indexPath)
		tableView:deselectRowAtIndexPath(indexPath);
		local hi = bself.historyList[indexPath:row() + 1];
		
		bself:gotoURLWithString(hi:url());
	end
	self.historyListTableView:setDelegate(historyListTableViewDelegate);
	
	self.observer = NotificationObserver:create():retain();
	function self.observer:didReceive(object, userInfo)
		local nsvalue = userInfo:objectForKey("UIKeyboardFrameEndUserInfoKey");
		local application = runtime::invokeClassMethod("UIApplication", "sharedApplication");
		local interfaceOrientation = runtime::invokeMethod(application, "statusBarOrientation");
		interfaceOrientation=tonumber(interfaceOrientation);
		local frame = runtime::invokeMethod(nsvalue:id(), "CGRectValue");
		local x,y,wid,hei = unpack(stringTableToNumberTable(stringSplit(frame, ",")));
		local tx,ty,tw,th = bself.historyListTableView:bounds();
		local _,_,_,vh = bself:view():bounds();
		local _,_,_,toolbarhei = bself:navigationController():toolbar():frame();
		vh =vh + toolbarhei;
		local anim = UIAnimation:create();
		function anim:animation()
			if interfaceOrientation == 3 or interfaceOrientation == 4 then
				hei = wid;
			end
			bself.historyListTableView:setFrame(0, 60, tw, vh - hei -60);
		end
		anim:start();
	end
	self.observer:observe("UIKeyboardWillShowNotification");
	
	self.hideObserver = NotificationObserver:create():retain();
	function self.hideObserver:didReceive(object, userInfo)
		local anim = UIAnimation:create();
		function anim:animation()
			local _,_,vw,viewHei=bself:view():bounds();
			bself.historyListTableView:setFrame(0, 60, vw, viewHei-60);
		end
		anim:start();
	end
	self.hideObserver:observe("UIKeyboardWillHideNotification");
	
	if self.initURLString then
		self:gotoURLWithString(self.initURLString);
    	end

	self.titleNO = NotificationObserver:create():retain();
	function self.titleNO:didReceive()
		bself:updateSwitchButtonList();
	end
	self.titleNO:observe("BROWSER_TITLE_UPDATE");
end

function MiniBrowserController:shouldAutorotate()
    return true;
end