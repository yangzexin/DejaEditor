require "UIKit"
require "DiarySentenceController"
require "MiniBrowserController"
require "BrowserTabListController"
require "BrowserViewController"

function main()
    local listVC = UIViewController:create("插件"):retain();
    
    function listVC:shouldAutorotate()
        return true;
    end
    function listVC:viewDidLoad()
        local bself = self;
        listVC.tableView = UITableView:createWithStyle(1):retain();
        listVC.tableView:setFrame(self:view():bounds());
        listVC.tableView:setAutoresizingMask(math::bitOr(UIViewAutoresizingFlexibleWidth, UIViewAutoresizingFlexibleHeight));
        listVC:view():addSubview(listVC.tableView);
        
        local tableViewDataSource = {};
        function tableViewDataSource:numberOfSections()
            return 1;
        end
        function tableViewDataSource:numberOfRowsInSection()
            return 2;
        end
        function tableViewDataSource:cellForRowAtIndexPath(tableView, indexPath)
            local cell = tableView:dequeueReusableCellWithIdentifier("__id");
            if not cell then
                cell = UITableViewCell:create("__id");
                cell:textLabel():setFont(UIFont:create(14));
                cell:setAccessoryType(1);
            end
            if indexPath:row() == 0 then
                cell:textLabel():setText("🎯 每日一句英语口语");
            elseif indexPath:row() == 1 then
                cell:textLabel():setText("✈ 迷你浏览器");
            end
            return cell;
        end
        listVC.tableView:setDataSource(tableViewDataSource);
        
        local tableViewDelegate = {};
        function tableViewDelegate:didSelectRowAtIndexPath(tableView, indexPath)
            tableView:deselectRowAtIndexPath(indexPath);
            if indexPath:row() == 0 then
                local diarySC = DiarySentenceController:create("每日一句"):retain();
                --diarySC:setHidesBottomBarWhenPushed(true);
                listVC:navigationController():pushViewController(diarySC);
                function diarySC:viewDidPop()
                    diarySC:release();
                end
            elseif indexPath:row() == 1 then
                --ui::dialog("", "该板块正在建设中", "我知道了");
                if not bself.browserVC then
                    bself.browserVC = BrowserViewController:create():retain();
                    function bself.browserVC:quit(background)
                        if not background then
                            bself.browserVC:release();
                            bself.browserVC = nil;
                        end
                    end
                end
                bself:presentViewController(bself.browserVC, true);
            end
        end
        listVC.tableView:setDelegate(tableViewDelegate);
    end
	
	if UIViewController.relatedNavigationController()  ~= nil then
		UIViewController:relatedNavigationController():pushViewController(listVC);
	else
		listVC:pushToRelatedViewController();
	end
end
