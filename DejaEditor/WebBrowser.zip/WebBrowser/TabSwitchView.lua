require "UIView"
require "NSArray"
require "UIImage"

class(TabSwitchView, UIView);

function TabSwitchView:dealloc()
	if self.buttonList then
		for i=1,#self.buttonList do
			safety_release(self.buttonList[i]);
		end
	end
	super:dealloc();
end

function TabSwitchView:init()
	super:init();
	self:setBackgroundColor(UIColor:create(255,0,0));
end

function TabSwitchView:reset(titleList, selectedIndex)
	local bself = self;
	if titleList == nil then
		return ;
	end
	if selectedIndex == nil then
		selectedIndex=0;
	end
	
	if #titleList == 0 then
		return ;
	end
	if self.buttonList then
		for i=1,#self.buttonList do
			safety_release(self.buttonList[i]);
		end
	end
	
	local subview = NSArray:get(runtime::invokeMethod(self:id(), "subviews"));
	for i = 0, subview:count()-1 do
		local btn = subview:objectAtIndex(i);
		runtime::invokeMethod(btn:id(), "removeFromSuperview");
	end
	self.buttonList = {};
	local vx,vy,vw,vh=self:bounds();
	local addButtonWidth = 40;
	local buttonWidth = (vw - addButtonWidth) / #titleList;
	for i=1,#titleList do
		local btn = UIButton:create(titleList[i], 0):retain();
		btn:setAutoresizingMask(math::bitOr(1,2));
		runtime::invokeMethod(btn:id(), "setTitleEdgeInsets:", toCStruct(0, 5, 0, 5));
		btn:titleLabel():setFont(UIFont:create(14, true));
		self.buttonList[i] = btn;
		function btn:didTap()
			bself:switchTab(i -1);
		end
		self.buttonList[i]:setFrame((i -1)* buttonWidth, 0, buttonWidth,vh);
		self:addSubview(self.buttonList[i]);
		
		self.buttonList[i]:setBackgroundColor(UIColor:create(0, 0, 0));
		if selectedIndex +1 == i then
			safety_release(self.closeButton);
			self.closeButton = UIButton:create("",0):retain();
			self.closeButton:setImage(UIImage:imageWithResName("closetab.png"));
			function self.closeButton:didTap()
				bself:closeTab(selectedIndex);
			end
			self.closeButton:setFrame(5, 0, 40, vh);
			self.closeButton:setImageEdgeInsets(5, 5, 5, 5);
			self.closeButton:setBackgroundColor(UIColor.clearColor());
			btn:addSubview(self.closeButton);
			runtime::invokeMethod(btn:id(), "setTitleColor:forState:", UIColor:create(0, 0, 0), 0);
			btn:setBackgroundColor(UIColor:create(255, 255, 255));
			runtime::invokeMethod(btn:id(), "setTitleEdgeInsets:", toCStruct(0, 45, 0, 5));
		end
	end
	
	safety_release(self.addButton);
	self.addButton = UIButton:create("",0):retain();
	self.addButton:setImage(UIImage:imageWithResName("addtab.png"));
	self.addButton:setImageEdgeInsets(5, 5, 5, 5);
	self.addButton:setBackgroundColor(UIColor:create(0, 0, 0));
	self.addButton:setAutoresizingMask(1);
	function self.addButton:didTap()
		bself:newTab();
	end
	self.addButton:setFrame(vw - addButtonWidth, 0, addButtonWidth, vh);
	self:addSubview(self.addButton);
end

function TabSwitchView:switchTab(index)

end

function TabSwitchView:newTab()
	
end

function TabSwitchView:closeTab(index)
	
end