require "Object"
require "FMResultSet"

class(FMDatabase);

function FMDatabase:databaseWithPath(path)
	local fmId = runtime::invokeClassMethod("FMDatabase", "databaseWithPath:", path);
	
	return self:get(fmId);
end

function FMDatabase:get(fmId)
	return self:new(fmId);
end

function FMDatabase:open()
	return toLuaBool(runtime::invokeMethod(self:id(), "open"));
end

function FMDatabase:close()
	return toLuaBool(runtime::invokeMethod(self:id(), "close"));
end

function FMDatabase:goodConnection()
	return toLuaBool(runtime::invokeMethod(self:id(), "goodConnection"));
end

function FMDatabase:executeUpdate(sql)
	return toLuaBool(runtime::invokeMethod(self:id(), "executeUpdate:", sql));
end

function FMDatabase:executeQuery(sql)
	return FMResultSet:get(runtime::invokeMethod(self:id(), "executeQuery:", sql));
end

function FMDatabase:dealloc()
	super:dealloc();
	self:close();
end