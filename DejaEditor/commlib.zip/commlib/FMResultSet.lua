require "Object"
class(FMResultSet);

function FMResultSet:get(rsId)
	return self:new(rsId);
end

function FMResultSet:close()
	runtime::invokeMethod(self:id(), "close");
end

function FMResultSet:next()
	return toLuaBool(runtime::invokeMethod(self:id(), "next"));
end

function FMResultSet:columnCount()
	return tonumber(runtime::invokeMethod(self:id(), "columnCount"));
end

function FMResultSet:columnIndexForName(columnName)
	return tonumber(runtime::invokeMethod(self:id(), "columnIndexForName:", columnName));
end

function FMResultSet:columnNameForIndex(columnIdx)
	return runtime::invokeMethod(self:id(), "columnNameForIndex:", columnIdx);
end

function FMResultSet:columnIndexIsNull(columnIdx)
	return toLuaBool(runtime::invokeMethod(self:id(), "columnIndexIsNull", columnIdx));
end

function FMResultSet:columnIsNull(columnName)
	return toLuaBool(runtime::invokeMethod(self:id(), "columnIsNull", columnName));
end

function FMResultSet:intForColumn(columnName)
	return runtime::invokeMethod(self:id(), "intForColumn", columnName);
end

function FMResultSet:intForColumnIndex(columnIdx)
	return runtime::invokeMethod(self:id(), "intForColumnIndex", columnName);
end

function FMResultSet:longForColumn(columnName)
	return runtime::invokeMethod(self:id(), "longForColumn", columnName);
end

function FMResultSet:longForColumnIndex(columnIdx)
	return runtime::invokeMethod(self:id(), "longForColumnIndex", columnName);
end

function FMResultSet:boolForColumn(columnName)
	return runtime::invokeMethod(self:id(), "boolForColumn", columnName);
end

function FMResultSet:boolForColumnIndex(columnIdx)
	return runtime::invokeMethod(self:id(), "boolForColumnIndex", columnName);
end

function FMResultSet:doubleForColumn(columnName)
	return runtime::invokeMethod(self:id(), "doubleForColumn", columnName);
end

function FMResultSet:doubleForColumnIndex(columnIdx)
	return runtime::invokeMethod(self:id(), "doubleForColumnIndex", columnName);
end

function FMResultSet:stringForColumn(columnName)
	return runtime::invokeMethod(self:id(), "stringForColumn", columnName);
end

function FMResultSet:stringForColumnIndex(columnIdx)
	return runtime::invokeMethod(self:id(), "stringForColumnIndex", columnName);
end







