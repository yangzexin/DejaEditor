require "FMDatabase"
require "FileUtils"

function main()
	local dbPath = 
		string::invokeMethod(FileUtils.tempPath(), "stringByAppendingPathComponent:","test.db" );
	FileUtils.removeItemAtPath(dbPath);
	local db = FMDatabase:databaseWithPath(dbPath);
	db:open();
	local sql = [===[
		create table bookmarks(
			uid Integer primary key autoincrement,
			name text,
			url text
		);
	]===];
	local success = db:executeUpdate(sql);
	if success then
		utils::log("create table success");
	else
		utils::log("create table failed");
	end
	sql = [===[
		insert into bookmarks(name, url) values("$name", "$url");
	]===];
	for i=1, 10 do
		local tmpSql = sql;
		tmpSql = string::invokeMethod(tmpSql, 
			"stringByReplacingOccurrencesOfString:withString:", 
			"$name", "name-"..i);
		tmpSql = string::invokeMethod(tmpSql, 
			"stringByReplacingOccurrencesOfString:withString:", 
			"$url", "http://www.google.com");
		utils::log(tmpSql);
		local result = db:executeUpdate(tmpSql);
		if result then
			utils::log("insert success");
		else
			utils::log("insert failed");
		end
	end
	
	sql = [===[
		select name,url from bookmarks;
	]===]
	local  rs = db:executeQuery(sql);
	while rs:next() do
		utils::log(rs:stringForColumn("name")..","..rs:stringForColumn("url"));
	end
	rs:close();
	db:close();
	return nil;
end
